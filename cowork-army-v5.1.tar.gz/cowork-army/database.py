"""
COWORK.ARMY — SQLite Database (WAL mode, thread-safe)
Tables: agents, tasks, events
"""
import sqlite3, json, threading, os
from datetime import datetime
from pathlib import Path

DB_PATH = Path(__file__).parent / "cowork.db"
_local = threading.local()

def _conn() -> sqlite3.Connection:
    if not hasattr(_local, "conn") or _local.conn is None:
        _local.conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
        _local.conn.row_factory = sqlite3.Row
        _local.conn.execute("PRAGMA journal_mode=WAL")
        _local.conn.execute("PRAGMA busy_timeout=5000")
    return _local.conn

def init_db():
    c = _conn()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS agents (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        icon TEXT DEFAULT '🤖',
        tier TEXT DEFAULT 'WORKER',
        color TEXT DEFAULT '#64748b',
        domain TEXT DEFAULT '',
        desc TEXT DEFAULT '',
        skills TEXT DEFAULT '[]',
        rules TEXT DEFAULT '[]',
        triggers TEXT DEFAULT '[]',
        system_prompt TEXT DEFAULT '',
        workspace_dir TEXT DEFAULT '',
        is_base INTEGER DEFAULT 0,
        created_at TEXT DEFAULT (datetime('now'))
    );
    CREATE TABLE IF NOT EXISTS tasks (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT DEFAULT '',
        assigned_to TEXT DEFAULT '',
        priority TEXT DEFAULT 'normal',
        status TEXT DEFAULT 'pending',
        created_by TEXT DEFAULT 'user',
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now')),
        log TEXT DEFAULT '[]'
    );
    CREATE TABLE IF NOT EXISTS events (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        timestamp TEXT DEFAULT (datetime('now')),
        agent_id TEXT DEFAULT '',
        message TEXT DEFAULT '',
        type TEXT DEFAULT 'info'
    );
    """)
    c.commit()

# ── Agent CRUD ──
def upsert_agent(a: dict):
    c = _conn()
    c.execute("""INSERT INTO agents (id,name,icon,tier,color,domain,desc,skills,rules,triggers,system_prompt,workspace_dir,is_base)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(id) DO UPDATE SET name=excluded.name,icon=excluded.icon,tier=excluded.tier,
        color=excluded.color,domain=excluded.domain,desc=excluded.desc,skills=excluded.skills,
        rules=excluded.rules,triggers=excluded.triggers,system_prompt=excluded.system_prompt,
        workspace_dir=excluded.workspace_dir,is_base=excluded.is_base""",
        (a["id"], a["name"], a.get("icon","🤖"), a.get("tier","WORKER"), a.get("color","#64748b"),
         a.get("domain",""), a.get("desc",""),
         json.dumps(a.get("skills",[])), json.dumps(a.get("rules",[])), json.dumps(a.get("triggers",[])),
         a.get("system_prompt",""), a.get("workspace_dir", a["id"]), a.get("is_base", 0)))
    c.commit()

def get_agents() -> list[dict]:
    rows = _conn().execute("SELECT * FROM agents ORDER BY is_base DESC, created_at").fetchall()
    return [_row_to_agent(r) for r in rows]

def get_agent(agent_id: str) -> dict | None:
    r = _conn().execute("SELECT * FROM agents WHERE id=?", (agent_id,)).fetchone()
    return _row_to_agent(r) if r else None

def delete_agent(agent_id: str) -> bool:
    c = _conn()
    r = c.execute("DELETE FROM agents WHERE id=? AND is_base=0", (agent_id,))
    c.commit()
    return r.rowcount > 0

def _row_to_agent(r) -> dict:
    return {
        "id": r["id"], "name": r["name"], "icon": r["icon"], "tier": r["tier"],
        "color": r["color"], "domain": r["domain"], "desc": r["desc"],
        "skills": json.loads(r["skills"]) if r["skills"] else [],
        "rules": json.loads(r["rules"]) if r["rules"] else [],
        "triggers": json.loads(r["triggers"]) if r["triggers"] else [],
        "system_prompt": r["system_prompt"], "workspace_dir": r["workspace_dir"],
        "is_base": bool(r["is_base"]), "created_at": r["created_at"],
    }

# ── Tasks ──
def create_task(task_id: str, title: str, desc: str, assigned_to: str, priority: str, created_by: str, status: str, log: list) -> dict:
    c = _conn()
    now = datetime.now().isoformat()
    c.execute("INSERT INTO tasks (id,title,description,assigned_to,priority,status,created_by,created_at,updated_at,log) VALUES (?,?,?,?,?,?,?,?,?,?)",
        (task_id, title, desc, assigned_to, priority, status, created_by, now, now, json.dumps(log, ensure_ascii=False)))
    c.commit()
    return get_task(task_id)

def get_tasks(limit=100) -> list[dict]:
    rows = _conn().execute("SELECT * FROM tasks ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
    return [_row_to_task(r) for r in rows]

def get_task(task_id: str) -> dict | None:
    r = _conn().execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
    return _row_to_task(r) if r else None

def update_task(task_id: str, **kwargs):
    c = _conn()
    sets = []
    vals = []
    for k, v in kwargs.items():
        if k == "log":
            v = json.dumps(v, ensure_ascii=False)
        sets.append(f"{k}=?")
        vals.append(v)
    sets.append("updated_at=?")
    vals.append(datetime.now().isoformat())
    vals.append(task_id)
    c.execute(f"UPDATE tasks SET {','.join(sets)} WHERE id=?", vals)
    c.commit()

def _row_to_task(r) -> dict:
    return {
        "id": r["id"], "title": r["title"], "description": r["description"],
        "assigned_to": r["assigned_to"], "priority": r["priority"], "status": r["status"],
        "created_by": r["created_by"], "created_at": r["created_at"], "updated_at": r["updated_at"],
        "log": json.loads(r["log"]) if r["log"] else [],
    }

# ── Events ──
def add_event(agent_id: str, message: str, etype: str = "info"):
    c = _conn()
    c.execute("INSERT INTO events (agent_id, message, type) VALUES (?,?,?)", (agent_id, message, etype))
    c.commit()

def get_events(limit=50, since="") -> list[dict]:
    if since:
        rows = _conn().execute("SELECT * FROM events WHERE timestamp>? ORDER BY id DESC LIMIT ?", (since, limit)).fetchall()
    else:
        rows = _conn().execute("SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [{"timestamp": r["timestamp"], "agent_id": r["agent_id"], "message": r["message"], "type": r["type"]} for r in rows]
