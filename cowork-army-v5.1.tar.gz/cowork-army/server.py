#!/usr/bin/env python3
"""
COWORK.ARMY — Server v5.1
FastAPI backend. Single-file API with all routes.
"""
import os, uuid, json, logging
from pathlib import Path
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware

from database import (
    init_db, get_agents, get_agent, upsert_agent, delete_agent,
    get_tasks, create_task, add_event, get_events,
)
from registry import seed_agents
from runner import spawn_agent, kill_agent, get_statuses, get_output
from commander import delegate_task, create_dynamic_agent
from autonomous import autonomous

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(name)s] %(message)s")
logger = logging.getLogger("cowork")

BASE = Path(__file__).parent
WORKSPACE = BASE / "workspace"


def _load_env():
    """Load .env into os.environ without external deps."""
    env = BASE / ".env"
    if env.exists():
        for line in env.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def _setup():
    """DB init, seed agents, create workspace dirs. Runs once at startup."""
    _load_env()
    init_db()
    seed_agents(upsert_agent)
    for a in get_agents():
        ws = WORKSPACE / a["workspace_dir"]
        for d in ("inbox", "output"):
            (ws / d).mkdir(parents=True, exist_ok=True)
        readme = ws / "README.md"
        if not readme.exists():
            readme.write_text(f"# {a['icon']} {a['name']}\n{a['desc']}\n")
        gorev = ws / "gorevler.md"
        if not gorev.exists():
            gorev.write_text(f"# {a['icon']} {a['name']} — Görevler\n\n## Aktif\n_Boş_\n")
    logger.info("✅ %d agents ready", len(get_agents()))


@asynccontextmanager
async def lifespan(_app):
    _setup()
    yield
    autonomous.stop()


app = FastAPI(title="COWORK.ARMY", version="5.1", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ═══ INFO ═══
@app.get("/api/info")
def api_info():
    return {
        "name": "COWORK.ARMY", "version": "5.1", "mode": "production",
        "agents": len(get_agents()),
        "autonomous": autonomous.running,
        "autonomous_ticks": autonomous.tick_count,
    }

# ═══ AGENTS CRUD ═══
@app.get("/api/agents")
def api_agents():
    return get_agents()

@app.get("/api/agents/{agent_id}")
def api_agent_detail(agent_id: str):
    a = get_agent(agent_id)
    return a if a else JSONResponse({"error": "Agent not found"}, 404)

@app.post("/api/agents")
def api_create_agent(
    agent_id: str = Form(...), name: str = Form(...), icon: str = Form("🤖"),
    domain: str = Form(""), desc: str = Form(""),
    skills: str = Form(""), rules: str = Form(""), triggers: str = Form(""),
    system_prompt: str = Form(""),
):
    return create_dynamic_agent(
        agent_id, name, icon, domain, desc,
        [s.strip() for s in skills.split(",") if s.strip()],
        [r.strip() for r in rules.split(",") if r.strip()],
        [t.strip() for t in triggers.split(",") if t.strip()],
        system_prompt,
    )

@app.put("/api/agents/{agent_id}")
def api_update_agent(
    agent_id: str, name: str = Form(""), icon: str = Form(""),
    domain: str = Form(""), desc: str = Form(""), system_prompt: str = Form(""),
):
    a = get_agent(agent_id)
    if not a:
        return JSONResponse({"error": "Agent not found"}, 404)
    for k, v in [("name", name), ("icon", icon), ("domain", domain), ("desc", desc), ("system_prompt", system_prompt)]:
        if v:
            a[k] = v
    upsert_agent(a)
    return get_agent(agent_id)

@app.delete("/api/agents/{agent_id}")
def api_delete_agent(agent_id: str):
    return {"deleted": delete_agent(agent_id), "agent_id": agent_id}

# ═══ LIFECYCLE ═══
@app.post("/api/agents/{agent_id}/spawn")
def api_spawn(agent_id: str, task: str = ""):
    return spawn_agent(agent_id, task)

@app.post("/api/agents/{agent_id}/kill")
def api_kill(agent_id: str):
    return kill_agent(agent_id)

@app.get("/api/agents/{agent_id}/output")
def api_output(agent_id: str):
    return {"lines": get_output(agent_id)}

@app.get("/api/statuses")
def api_statuses():
    return get_statuses()

# ═══ TASKS ═══
@app.get("/api/tasks")
def api_tasks():
    return get_tasks()

@app.post("/api/tasks")
def api_create_task(
    title: str = Form(...), description: str = Form(""),
    assigned_to: str = Form(""), priority: str = Form("normal"),
):
    if assigned_to:
        tid = f"TASK-{uuid.uuid4().hex[:8].upper()}"
        return create_task(tid, title, description, assigned_to, priority, "user", "pending", [])
    return delegate_task(title, description, priority)

# ═══ COMMANDER ═══
@app.post("/api/commander/delegate")
def api_delegate(title: str = Form(...), description: str = Form(""), priority: str = Form("normal")):
    return delegate_task(title, description, priority)

# ═══ AUTONOMOUS ═══
@app.post("/api/autonomous/start")
def api_auto_start():
    autonomous.start()
    return {"status": "started"}

@app.post("/api/autonomous/stop")
def api_auto_stop():
    autonomous.stop()
    return {"status": "stopped"}

@app.get("/api/autonomous/status")
def api_auto_status():
    return autonomous.status()

@app.get("/api/autonomous/events")
def api_auto_events(limit: int = 50, since: str = ""):
    return get_events(limit, since)

# ═══ SETTINGS ═══
@app.get("/api/settings/api-key-status")
def api_key_status():
    key = os.environ.get("ANTHROPIC_API_KEY", "")
    return {"set": bool(key), "preview": (key[:12] + "...") if key else ""}

@app.post("/api/settings/api-key")
def api_set_key(key: str = Form(...)):
    env_path = BASE / ".env"
    lines = []
    if env_path.exists():
        lines = [l for l in env_path.read_text().splitlines() if not l.startswith("ANTHROPIC_API_KEY=")]
    lines.append(f"ANTHROPIC_API_KEY={key}")
    env_path.write_text("\n".join(lines) + "\n")
    os.environ["ANTHROPIC_API_KEY"] = key
    return {"status": "saved", "preview": key[:12] + "..."}

# ═══ WORKSPACE ═══
@app.get("/api/workspace/{agent_id}")
def api_workspace(agent_id: str):
    a = get_agent(agent_id)
    if not a:
        return JSONResponse({"error": "Agent not found"}, 404)
    ws = WORKSPACE / a["workspace_dir"]
    files = []
    if ws.exists():
        for f in sorted(ws.rglob("*")):
            if f.is_file():
                files.append({"path": str(f.relative_to(ws)), "size": f.stat().st_size})
    return {"agent_id": agent_id, "workspace": str(ws), "files": files}

@app.get("/api/workspace/{agent_id}/file")
def api_ws_file(agent_id: str, path: str = ""):
    a = get_agent(agent_id)
    if not a:
        return JSONResponse({"error": "Agent not found"}, 404)
    fp = (WORKSPACE / a["workspace_dir"] / path).resolve()
    if not str(fp).startswith(str(WORKSPACE.resolve())):
        return JSONResponse({"error": "Access denied"}, 403)
    if not fp.exists():
        return JSONResponse({"error": "File not found"}, 404)
    try:
        return {"path": path, "content": fp.read_text()[:50000]}
    except Exception:
        return {"path": path, "content": "[binary]", "size": fp.stat().st_size}

# ═══ FILE UPLOAD ═══
@app.post("/api/courier/upload")
async def api_upload(file: UploadFile = File(...)):
    inbox = WORKSPACE / "supervisor" / "inbox"
    inbox.mkdir(parents=True, exist_ok=True)
    dest = inbox / file.filename
    content = await file.read()
    dest.write_bytes(content)
    result = delegate_task(f"Dosya işle: {file.filename}", f"Dosya: {file.filename} ({len(content)} bytes)")
    return {"file": file.filename, "size": len(content), "routed_to": result.get("assigned_to", "supervisor"), "task": result}

# ═══ MAIN ═══
if __name__ == "__main__":
    print("═" * 50)
    print("  👑 COWORK.ARMY v5.1 — Command Center")
    print("  📡 http://localhost:8888")
    print("═" * 50)
    uvicorn.run(app, host="0.0.0.0", port=8888)
