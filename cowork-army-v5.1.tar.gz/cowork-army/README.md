# 👑 COWORK.ARMY v5.1

AI Agent ordusu kontrol merkezi. 12 base agent + dinamik agent desteği, otonom döngü, 3D görselleştirme.

## Hızlı Başlangıç

```bash
# Backend (FastAPI, port 8888)
cd cowork-army
pip install -r requirements.txt
python server.py

# Frontend (Next.js 15, port 3333) — ayrı terminal
cd cowork-army/frontend
npm install
npm run dev
```

Tarayıcıda `http://localhost:3333` açın. İlk açılışta API key istenir → [console.anthropic.com/settings/keys](https://console.anthropic.com/settings/keys)

## Mimari

```
Browser (localhost:3333)
   ↓ /cowork-api/* proxy
Backend (localhost:8888)
   ↓
SQLite (cowork.db) + Claude API (Anthropic)
   ↓
workspace/ (agent dosya sistemi)
```

## 12 Base Agent

| Agent | Rol | Tier |
|---|---|---|
| 👑 commander | Yönetim & Koordinasyon | COMMANDER |
| 🕵️ supervisor | Kalite Kontrol | SUPERVISOR |
| 🏥 med-health | Medikal Sağlık | DIRECTOR |
| ✈️ travel-agent | Seyahat + Otel | DIRECTOR |
| 🧠 trade-engine | Trading Swarm Beyni | DIRECTOR |
| 🔍 alpha-scout | Sentiment Analiz | WORKER |
| 📏 tech-analyst | Teknik Analiz | WORKER |
| 🛡️ risk-sentinel | Risk Yönetimi (VETO) | WORKER |
| 🔬 quant-lab | Backtest & Optimizasyon | WORKER |
| 🚀 growth-ops | Pazarlama & CRM | WORKER |
| 💻 web-dev | Full-Stack Dev | WORKER |
| 💰 finance | Finans & Muhasebe | WORKER |

## API

Tüm endpointler `GET/POST /api/*` altında. Detaylar → [CLAUDE.md](./CLAUDE.md)

## Deploy

- **Frontend**: Railway (`NEXT_PUBLIC_COWORK_API_URL` env var)
- **Backend**: Cloudflare Tunnel → localhost:8888
- **Domain**: ireska.com

## Dosyalar

| Dosya | Satır | Açıklama |
|---|---|---|
| server.py | ~180 | FastAPI routes |
| database.py | ~150 | SQLite WAL, 3 tablo |
| registry.py | ~130 | 12 agent tanımı |
| runner.py | ~170 | Claude API streaming |
| commander.py | ~70 | Task routing |
| autonomous.py | ~80 | Tick-based döngü |
| tools.py | ~130 | Agent workspace tools |
| frontend/app/page.tsx | ~250 | 3-panel UI |
| frontend/.../CoworkOffice3D.tsx | ~200 | Three.js 3D sahne |
