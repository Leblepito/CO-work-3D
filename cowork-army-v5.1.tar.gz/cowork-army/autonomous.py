"""
COWORK.ARMY — Autonomous Loop (tick-based)
Periodically checks inboxes, triggers agents, logs events.
"""
import threading, time, json
from datetime import datetime
from pathlib import Path
from database import get_agents, get_events, add_event
from runner import spawn_agent, PROCS

WORKSPACE = Path(__file__).parent / "workspace"

class AutonomousLoop:
    def __init__(self):
        self.running = False
        self.tick_count = 0
        self.thread: threading.Thread | None = None
        self.last_tick = None

    def start(self):
        if self.running: return
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()
        add_event("system", "Otonom döngü başlatıldı", "info")

    def stop(self):
        self.running = False
        add_event("system", "Otonom döngü durduruldu", "info")

    def _loop(self):
        while self.running:
            try:
                self._tick()
            except Exception as e:
                add_event("system", f"Tick hatası: {e}", "warning")
            time.sleep(30)  # 30 saniye aralık

    def _tick(self):
        self.tick_count += 1
        self.last_tick = datetime.now().isoformat()
        agents = get_agents()

        for agent in agents:
            aid = agent["id"]
            inbox = WORKSPACE / aid / "inbox"
            if not inbox.exists(): continue

            tasks = list(inbox.glob("TASK-*.json"))
            if not tasks: continue

            # Agent idle and has tasks → spawn
            if aid not in PROCS or not PROCS[aid].alive:
                try:
                    t = json.loads(tasks[0].read_text())
                    add_event(aid, f"Inbox'ta görev bulundu: {t.get('title','?')[:50]}", "inbox_check")
                    spawn_agent(aid, f"{t['title']}: {t.get('description','')}")
                except: pass

    def status(self) -> dict:
        return {
            "running": self.running,
            "tick_count": self.tick_count,
            "total_events": len(get_events(limit=999)),
            "agents_tracked": len(get_agents()),
            "last_tick": self.last_tick,
        }

autonomous = AutonomousLoop()
