# CLAUDE.md — COWORK.ARMY

Sen **COWORK.ARMY Commander Agent**'issin. Bu platform, AI agent ordusunu yoneten, gorev dagitan, koordine eden ve calistiran bir kontrol merkezidir.

## Proje Yapisi

```
cowork-army/                         ← Backend (FastAPI, port 8888)
├── server.py                        → Ana sunucu, tum API route'lari
├── database.py                      → SQLite DB (agents, tasks, events)
├── registry.py                      → 12 base agent tanimi (BASE_AGENTS)
├── runner.py                        → Agent lifecycle: spawn → run → done/error
├── autonomous.py                    → Otonom dongu (tick-based agent koordinasyonu)
├── commander.py                     → Keyword-based task routing + dinamik agent olusturma
├── tools.py                         → Agent tool definitions (read/write/search/run)
├── requirements.txt                 → Python bagimliliklari
├── .env                             → ANTHROPIC_API_KEY (gitignore'da)
├── cowork.db                        → SQLite veritabani (gitignore'da)
├── workspace/                       ← Agent workspace'leri (12 klasor)
└── frontend/                        ← Frontend (Next.js 15, port 3333)
    ├── app/page.tsx                 → Ana sayfa: 3-panel layout + modals
    ├── lib/cowork-api.ts            → Backend API client
    └── components/cowork-army/
        ├── CoworkOffice3D.tsx       → 3D ofis sahnesi (Three.js/R3F)
        ├── scene-constants.ts       → Pozisyonlar, zone'lar, sabitler
        └── utils.ts                 → Karakter, hareket, isbirligi yardimcilari
```

## Mimari

```
Telefon/Browser → Frontend (Railway / localhost:3333)
                      ↓ API calls
                  Backend (Cloudflare Tunnel / localhost:8888)
                      ↓
                  SQLite DB (cowork.db)
                      ↓
                  Claude API (Anthropic)
                      ↓
                  Aktif Projeler/ (dosya okuma/yazma)
```

## Agent Sistemi

### Base Agents (12 sabit)
Registry'de tanimli, DB'ye seed edilen, silinemez agentlar:

| ID | Rol | Tier |
|---|---|---|
| commander | Yonetici | COMMANDER |
| supervisor | Denetci | SUPERVISOR |
| med-health | Medikal Saglik | DIRECTOR |
| travel-agent | Seyahat + Otel | DIRECTOR |
| trade-engine | Trading Orchestrator | DIRECTOR |
| alpha-scout | Sentiment Hunter | WORKER |
| tech-analyst | Teknik Analiz | WORKER |
| risk-sentinel | Risk Guardian | WORKER |
| quant-lab | Nightly Optimizer | WORKER |
| growth-ops | Buyume & Pazarlama | WORKER |
| web-dev | Full-Stack Dev | WORKER |
| finance | Finans & Muhasebe | WORKER |

### Dinamik Agentlar
- UI'dan manuel olusturulabilir ("+ Yeni" butonu)
- Commander auto-route eslesmezse otomatik olusturulur
- SQLite'a kaydedilir, silinebilir
- 3D sahnede "DYNAMIC AGENTS" zone'unda gorunur
- Hash-based prosedural karakter olusturma

## API Endpoints

### Agent CRUD
- `GET /api/agents` — Tum agentlar
- `GET /api/agents/:id` — Tek agent
- `POST /api/agents` — Yeni dinamik agent (FormData)
- `PUT /api/agents/:id` — Agent guncelle
- `DELETE /api/agents/:id` — Dinamik agent sil

### Agent Lifecycle
- `POST /api/agents/:id/spawn?task=...` — Agent baslat
- `POST /api/agents/:id/kill` — Agent durdur
- `GET /api/agents/:id/output` — Terminal output
- `GET /api/statuses` — Tum agent durumlari

### Tasks
- `GET /api/tasks` — Gorev listesi
- `POST /api/tasks` — Gorev olustur (FormData)

### Commander
- `POST /api/commander/delegate` — Otomatik gorev yonlendirme + spawn

### Autonomous Loop
- `POST /api/autonomous/start` — Otonom dongu baslat
- `POST /api/autonomous/stop` — Durdur
- `GET /api/autonomous/status` — Durum
- `GET /api/autonomous/events` — Event feed

### Settings
- `GET /api/settings/api-key-status` — API key durumu
- `POST /api/settings/api-key` — API key kaydet

## Calistirma

```bash
# Backend
cd cowork-army
pip install -r requirements.txt
python server.py                    # port 8888

# Frontend
cd cowork-army/frontend
npm install
npm run dev                         # port 3333
```

## Database

SQLite, 3 tablo:
- **agents**: id, name, icon, tier, color, domain, desc, skills, rules, triggers, system_prompt, workspace_dir, is_base, created_at
- **tasks**: id, title, description, assigned_to, priority, status, created_by, created_at, log
- **events**: id, timestamp, agent_id, message, type

WAL mode, thread-safe writes.

## Deploy

- **Frontend**: Railway (NEXT_PUBLIC_COWORK_API_URL env var)
- **Backend**: Cloudflare Tunnel → localhost:8888
- **Domain**: ireska.com

## Kodlama Kurallari

1. Once dosyayi oku, mevcut pattern'i anla, sonra duzenle
2. TypeScript strict mode (frontend)
3. Conventional Commits: `feat:`, `fix:`, `refactor:`
4. `.env` dosyalarini asla commit etme
5. API key, secret, credentials kodda birakma
6. Yeni paket eklerken dikkatli ol
7. Database migration'larda veri kaybi riski varsa uyar

---

*COWORK.ARMY v5.1 — 12 base + dinamik agent destegi, SQLite persistence, 3D gorsellestime*
