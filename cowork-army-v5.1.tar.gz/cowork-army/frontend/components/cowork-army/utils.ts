/**
 * COWORK.ARMY — 3D Scene Utilities
 * Character generation, movement, collaboration beams — all in one.
 */

// ── Character Colors (hash-based for dynamic agents) ──
export function getCharacterColor(agentId: string): string {
  let hash = 0;
  for (let i = 0; i < agentId.length; i++) {
    hash = ((hash << 5) - hash) + agentId.charCodeAt(i);
    hash |= 0;
  }
  return `hsl(${Math.abs(hash) % 360}, 70%, 60%)`;
}

// ── Movement Parameters (status-driven animations) ──
export function getMovementParams(status: string): { speed: number; amplitude: number; bobFreq: number } {
  switch (status) {
    case "working": return { speed: 2, amplitude: 0, bobFreq: 0 };
    case "thinking": return { speed: 0, amplitude: 0.05, bobFreq: 2 };
    case "coding":  return { speed: 3, amplitude: 0, bobFreq: 0 };
    default:        return { speed: 0, amplitude: 0.03, bobFreq: 1.5 };
  }
}

// ── Collaboration Beams (trading swarm connections) ──
export interface CollabBeam {
  from: string;
  to: string;
  color: string;
  intensity: number;
}

const TRADING_SWARM = ["trade-engine", "alpha-scout", "tech-analyst", "risk-sentinel", "quant-lab"];

export function getActiveCollaborations(statuses: Record<string, { status: string }>): CollabBeam[] {
  const beams: CollabBeam[] = [];
  const activeTraders = Object.entries(statuses)
    .filter(([id, s]) => TRADING_SWARM.includes(id) && ["working", "coding", "thinking"].includes(s.status));

  if (activeTraders.length >= 2) {
    for (let i = 1; i < activeTraders.length; i++) {
      beams.push({ from: "trade-engine", to: activeTraders[i][0], color: "#a78bfa", intensity: 0.5 });
    }
  }
  return beams;
}
