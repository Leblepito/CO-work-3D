/** COWORK.ARMY — 3D Scene Constants */

export const DESK_POSITIONS: Record<string, [number, number, number]> = {
  // Yönetim (sol üst)
  commander:      [-8, 0, -6],
  supervisor:     [-6, 0, -6],
  // Medikal & Seyahat (sol alt)
  "med-health":   [-8, 0, -2],
  "travel-agent": [-6, 0, -2],
  // Trading Swarm (orta)
  "trade-engine": [ 0, 0, -4],
  "alpha-scout":  [-2, 0, -2],
  "tech-analyst": [ 2, 0, -2],
  "risk-sentinel":[-2, 0, -6],
  "quant-lab":    [ 2, 0, -6],
  // Operasyon (sağ)
  "growth-ops":   [ 6, 0, -6],
  "web-dev":      [ 8, 0, -6],
  "finance":      [ 6, 0, -4],
};

export const ZONES = [
  {
    id: "management",
    label: "YÖNETIM",
    color: "#fbbf24",
    center: [-7, 0, -6] as [number, number, number],
    size: [4, 2] as [number, number],
    agents: ["commander", "supervisor"],
  },
  {
    id: "medical",
    label: "MEDİKAL & SEYAHAT",
    color: "#22d3ee",
    center: [-7, 0, -2] as [number, number, number],
    size: [4, 2] as [number, number],
    agents: ["med-health", "travel-agent"],
  },
  {
    id: "trading",
    label: "TRADING SWARM",
    color: "#a78bfa",
    center: [0, 0, -4] as [number, number, number],
    size: [6, 6] as [number, number],
    agents: ["trade-engine", "alpha-scout", "tech-analyst", "risk-sentinel", "quant-lab"],
  },
  {
    id: "operations",
    label: "OPERASYON",
    color: "#22c55e",
    center: [7, 0, -5] as [number, number, number],
    size: [4, 4] as [number, number],
    agents: ["growth-ops", "web-dev", "finance"],
  },
];

export const TIER_COLORS: Record<string, string> = {
  COMMANDER: "#fbbf24",
  SUPERVISOR: "#f43f5e",
  DIRECTOR: "#a78bfa",
  WORKER: "#64748b",
};

export const STATUS_COLORS: Record<string, string> = {
  idle: "#64748b",
  working: "#22c55e",
  searching: "#f59e0b",
  thinking: "#8b5cf6",
  coding: "#3b82f6",
  planning: "#f97316",
  error: "#ef4444",
  done: "#22c55e",
};
