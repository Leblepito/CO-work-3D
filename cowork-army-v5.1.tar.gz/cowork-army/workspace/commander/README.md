# 👑 Commander
Tüm agent'ları yönetir, strateji belirler, bütçe onaylar, görev dağıtır.
